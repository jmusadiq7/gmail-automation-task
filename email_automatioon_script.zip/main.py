import os
import base64
import csv
import schedule
import time
from datetime import datetime
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from email.message import EmailMessage

SCOPES = ['https://www.googleapis.com/auth/gmail.send']

def get_gmail_service():
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            print(">>> Opening browser for authentication...")
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        
        # Save the credentials
        with open('token.json', 'w') as token:
            token.write(creds.to_json())
        print(">>> SUCCESS: token.json created!")
        time.sleep(2) # Give the system a second to breathe
    
    return build('gmail', 'v1', credentials=creds)

def send_scheduled_email():
    recipient = "jmusadiq7@gmail.com" 
    
    try:
        service = get_gmail_service()
        message = EmailMessage()
        message.set_content("Automated email test successful!")
        message['To'] = recipient
        message['Subject'] = "Internship Task 2: Success"
        
        # CORRECTED LINE BELOW:
        encoded_message = base64.urlsafe_b64encode(message.as_bytes()).decode()
        
        service.users().messages().send(userId="me", body={'raw': encoded_message}).execute()
        
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Email sent to {recipient}")
        log_transaction(recipient, "SUCCESS")
    except Exception as e:
        print(f"Error: {e}")
        log_transaction(recipient, f"FAILED: {e}")

def log_transaction(recipient, status):
    with open('email_history.csv', 'a', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([datetime.now(), recipient, status])

if __name__ == "__main__":
    # Send one immediately to test
    send_scheduled_email()
    
    # Schedule for every 1 minute
    schedule.every(1).minutes.do(send_scheduled_email)
    
    print("Script running... press Ctrl+C to stop.")
    while True:
        schedule.run_pending()
        time.sleep(1)